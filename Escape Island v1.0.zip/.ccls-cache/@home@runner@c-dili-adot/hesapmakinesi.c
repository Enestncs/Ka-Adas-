#include <stdio.h>

int hesapmakine() {
    char op;
    double num1, num2, result;
    char choice;

    do {
        printf("Bir işlem seçiniz (+, -, *, /): ");
        scanf(" %c", &op);

        printf("Birinci sayıyı giriniz: ");
        scanf("%lf", &num1);

        printf("İkinci sayıyı giriniz: ");
        scanf("%lf", &num2);

        switch(op) {
            case '+':
                result = num1 + num2;
                printf("%.2lf + %.2lf = %.2lf\n", num1, num2, result);
                break;

            case '-':
                result = num1 - num2;
                printf("%.2lf - %.2lf = %.2lf\n", num1, num2, result);
                break;

            case '*':
                result = num1 * num2;
                printf("%.2lf * %.2lf = %.2lf\n", num1, num2, result);
                break;

            case '/':
                if (num2 != 0) {
                    result = num1 / num2;
                    printf("%.2lf / %.2lf = %.2lf\n", num1, num2, result);
                } else {
                    printf("Hata: Sıfıra bölme yapılamaz.\n");
                }
                break;

            default:
                printf("Geçersiz işlem.\n");
                break;
        }

        printf("Yeni bir işlem denemek ister misiniz? (E/e - Evet, H/h - Hayır): ");
        scanf(" %c", &choice);

    } while(choice == 'E' || choice == 'e');

    printf("Programdan çıkılıyor...\n");

    return 0;
}
