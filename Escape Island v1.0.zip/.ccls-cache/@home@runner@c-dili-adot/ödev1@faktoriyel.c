#include <stdio.h>

int faktoriyel() {
    int n = 0;
    char devamEtmek = 'E';

    do {
        printf("Faktöriyeli alınacak sayıyı girin: ");
        scanf("%d", &n);

        while (n < 0) {
            printf("Hatalı giriş! Lütfen pozitif bir tam sayı girin: ");
            scanf("%d", &n);
        }

        int faktor = 1;
        for (int sayac = n; sayac >= 1; sayac--) {
            faktor *= sayac;
        }

        printf("\n%d sayısının faktöriyeli: %d\n", n, faktor);


        printf("Başka bir sayının faktöriyelini hesaplamak ister misiniz? (E/H): ");
        scanf(" %c", &devamEtmek);

    } while (devamEtmek == 'E' || devamEtmek == 'e');

    printf("Program sonlandırılıyor...\n");
    return 0;
}