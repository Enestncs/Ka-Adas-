#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

// Envanter için struct tanımı
typedef struct {
    char name[20];
    int quantity;
} Item;

typedef struct {
    char name[20];         // Eşyanın adı
    char materials[3][20]; // Gerekli malzemeler
    int quantities[3];     // Gerekli malzeme miktarları
    int materialCount;     // Kaç farklı malzeme gerektiği
} Recipe;

Item inventory[10]; // Maksimum 10 itemlik envanter
int itemCount = 0;  // Envanterdeki item sayısı

int energy = 10;    // Oyuncunun başlangıç enerjisi
int health = 3;     // Oyuncunun başlangıç canı

Recipe recipes[] = {
    {"Balta", {"Odun", "Taş"}, {2, 1}, 2},
    {"Bıçak", {"Kemik"}, {1}, 1},
    {"Tekne", {"Odun", "İp", "Kumaş"}, {3, 2, 1}, 3}
};
int recipeCount = sizeof(recipes) / sizeof(Recipe);

// Fonksiyon Prototipleri
void explore();
void randomEvent();
void addItem(char *name, int quantity);
void displayInventory();
void displayStats();
void craftItem();
void tryToEscape();
void consumeEnergy(int amount);

// Ana Fonksiyon
int mains() {
    int choice;
    srand(time(NULL)); // Rastgelelik için zaman tabanlı seed

    printf("Fırtına sonrası gözlerini açıyorsun. Nerede olduğunu bilmiyorsun.\n");
    printf("Adadan kaçmak için bir bot yapman gerekiyor!\n");
    printf("Bot için malzemeler: Odun, ip ve kumaş.\n");

    while (1) {
        if (energy <= 0) {
            printf("\nEnerjin kalmadı! Dinlenmek zorundasın.\n");
            printf("Dinleniyorsun ve enerjin 5 puan arttı.\n");
            energy += 5;
        }

        if (health <= 0) {
            printf("\nCanın tükendi! Adada hayatta kalmayı başaramadın.\n");
            return 0;
        }

        printf("\nNe yapmak istiyorsun?\n");
        printf("1. Dolaş\n");
        printf("2. Envanteri göster\n");
        printf("3. İstatistikleri göster\n");
        printf("4. Kaçmayı dene\n");
        printf("5. Craft yap\n");
        printf("6. Çıkış yap\n");
        printf("Seçimin: ");
        if (scanf("%d", &choice) != 1) {
            printf("Geçersiz giriş. Program sonlandırılıyor.\n");
            break;
        }

        switch (choice) {
            case 1:
                explore();
                break;
            case 2:
                displayInventory();
                break;
            case 3:
                displayStats();
                break;
            case 4:
                tryToEscape();
                break;
            case 5:
                craftItem();
                break;
            case 6:
                printf("Oyundan çıktınız. Adada mahsur kaldınız.\n");
                return 0;
            default:
                printf("Geçersiz seçim. Lütfen tekrar deneyin.\n");
        }
    }
    return 0;
}

// İstatistikleri Gösterme
void displayStats() {
    printf("\nİstatistikler:\n");
    printf("Enerji: %d\n", energy);
    printf("Can: %d\n", health);
}

// Rastgele Dolaşma Fonksiyonu
void explore() {
    printf("\nEtrafta dolaşıyorsun...\n");
    randomEvent();
}

// Rastgele Olay Fonksiyonu
void randomEvent() {
    int event = rand() % 5; // 5 farklı olay (0, 1, 2, 3, 4)

    switch (event) {
        case 0:
            addItem("Odun", 1);
            printf("Odun buldun!\n");
            break;
        case 1:
            addItem("İp", 1);
            printf("İp buldun!\n");
            break;
        case 2:
            addItem("Kumaş", 1);
            printf("Kumaş buldun!\n");
            break;
        case 3:
            addItem("Kemik", 1);
            printf("Bir iskelet buldun ve kemik topladın!\n");
            break;
        case 4:
            addItem("Taş", 1);
            printf("Yerde bir taş buldun!\n");
            break;
        default:
            printf("Hiçbir şey bulamadın. Şansını bir daha dene.\n");
    }
}

// Enerji Tüketimi
void consumeEnergy(int amount) {
    if (energy < amount) {
        printf("Yeterli enerjin yok! Bu eylemi gerçekleştiremiyorsun.\n");
    } else {
        energy -= amount;
    }
}

// Yeni Item Ekleme veya Güncelleme Fonksiyonu
void addItem(char *name, int quantity) {
    for (int i = 0; i < itemCount; i++) {
        if (strcmp(inventory[i].name, name) == 0) {
            inventory[i].quantity += quantity;
            printf("%s miktarı güncellendi: %d\n", name, inventory[i].quantity);
            return;
        }
    }
    if (itemCount < 10) {
        strcpy(inventory[itemCount].name, name);
        inventory[itemCount].quantity = quantity;
        itemCount++;
        printf("%s envantere eklendi: %d\n", name, quantity);
    } else {
        printf("Envanter dolu! Yeni item eklenemiyor.\n");
    }
}

// Envanteri Gösterme Fonksiyonu
void displayInventory() {
    printf("\nMevcut Envanter:\n");
    for (int i = 0; i < itemCount; i++) {
        printf("%s: %d\n", inventory[i].name, inventory[i].quantity);
    }
}

// Craft Yapma Fonksiyonu
void craftItem() {
    printf("\nCraft edilebilecek eşyalar:\n");
    for (int i = 0; i < recipeCount; i++) {
        printf("%d. %s (", i + 1, recipes[i].name);
        for (int j = 0; j < recipes[i].materialCount; j++) {
            printf("%s: %d", recipes[i].materials[j], recipes[i].quantities[j]);
            if (j < recipes[i].materialCount - 1) printf(", ");
        }
        printf(")\n");
    }
    printf("Craft etmek istediğiniz eşyanın numarasını girin: ");
    int choice;
    if (scanf("%d", &choice) != 1 || choice < 1 || choice > recipeCount) {
        printf("Geçersiz seçim.\n");
        return;
    }

    Recipe selectedRecipe = recipes[choice - 1];

    for (int i = 0; i < selectedRecipe.materialCount; i++) {
        int found = 0;
        for (int j = 0; j < itemCount; j++) {
            if (strcmp(inventory[j].name, selectedRecipe.materials[i]) == 0 &&
                inventory[j].quantity >= selectedRecipe.quantities[i]) {
                found = 1;
                break;
            }
        }
        if (!found) {
            printf("Yeterli %s yok. Craft işlemi başarısız.\n", selectedRecipe.materials[i]);
            return;
        }
    }

    for (int i = 0; i < selectedRecipe.materialCount; i++) {
        for (int j = 0; j < itemCount; j++) {
            if (strcmp(inventory[j].name, selectedRecipe.materials[i]) == 0) {
                inventory[j].quantity -= selectedRecipe.quantities[i];
            }
        }
    }
    printf("%s craft edildi!\n", selectedRecipe.name);
    addItem(selectedRecipe.name, 1);
}

// Kaçma Fonksiyonu
void tryToEscape() {
    int hasBoat = 0;
    for (int i = 0; i < itemCount; i++) {
        if (strcmp(inventory[i].name, "Tekne") == 0) {
            hasBoat = 1;
            break;
        }
    }

    if (hasBoat) {
        printf("Tebrikler! Botu yapmayı başardınız ve adadan başarıyla kaçtınız.\n");
        exit(0);
    } else {
        printf("\nHenüz bir bot yapmadınız! Kaçmak için bir bot yapmanız gerekiyor.\n");
    }
}
