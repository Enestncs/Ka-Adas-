#include "stdio.h"
#include <vector>

int main(void) {
  
  
 


  
  return 0;
}
