#include <stdio.h>

// Malzemeleri depolamak için global bir array
int materials[3] = {0, 0, 0}; // 0: odun, 1: ip, 2: kumaş

// Fonksiyon prototipleri
void collectWood();
void collectRope();
void collectFabric();
void displayMaterials();
void buildBoat();

int main() {
    int choice;
    printf("Fırtına sonrası gözlerini açıyorsun. Nerede olduğunu bilmiyorsun.\n");
    printf("Adadan kaçmak için bir bot yapman gerekiyor!\n");
    printf("Bot için malzemeler: Odun, ip ve kumaş.\n");

    while (1) {
        printf("\nNe yapmak istiyorsun?\n");
        printf("1. Odun topla\n");
        printf("2. İp topla\n");
        printf("3. Kumaş topla\n");
        printf("4. Malzeme durumunu göster\n");
        printf("5. Bot yapmayı dene\n");
        printf("6. Çıkış yap\n");
        printf("Seçimin: ");
        if (scanf("%d", &choice) != 1) { // Hatalı giriş kontrolü
            printf("Geçersiz giriş. Program sonlandırılıyor.\n");
            break;
        }

        switch (choice) {
            case 1:
                collectWood();
                break;
            case 2:
                collectRope();
                break;
            case 3:
                collectFabric();
                break;
            case 4:
                displayMaterials();
                break;
            case 5:
                buildBoat();
                return 0; // Oyunu bitir
            case 6:
                printf("Oyundan çıktınız. Adada mahsur kaldınız.\n");
                return 0;
            default:
                printf("Geçersiz seçim. Lütfen tekrar deneyin.\n");
        }
    }
    return 0;
}

// Odun toplama fonksiyonu
void collectWood() {
    int answer;
    printf("\nOdun toplamak için bir soru cevaplamalısın:\n");
    printf("Bir ağacın dalını kesmek için her dalda 2 dakikanı harcıyorsun.\n");
    printf("Eğer 6 dal kesersen toplamda kaç dakika harcamış olursun? ");
    if (scanf("%d", &answer) != 1) {
        printf("Geçersiz giriş. Odun toplanamadı.\n");
        return;
    }

    if (answer == 12) {
        printf("Doğru cevap! Bir odun topladın.\n");
        materials[0]++; // Odun sayısını artır
    } else {
        printf("Yanlış cevap! Odunu toplayamadın.\n");
    }
}

// İp toplama fonksiyonu
void collectRope() {
    int answer;
    printf("\nİp toplamak için bir soru cevaplamalısın:\n");
    printf("Bir ip parçasını 4 eşit parçaya kesmek istiyorsun.\n");
    printf("Kaç kesim yapman gerekir? ");
    if (scanf("%d", &answer) != 1) {
        printf("Geçersiz giriş. İp toplanamadı.\n");
        return;
    }

    if (answer == 3) {
        printf("Doğru cevap! Bir ip topladın.\n");
        materials[1]++; // İp sayısını artır
    } else {
        printf("Yanlış cevap! İpi toplayamadın.\n");
    }
}

// Kumaş toplama fonksiyonu
void collectFabric() {
    int answer;
    printf("\nKumaş toplamak için bir soru cevaplamalısın:\n");
    printf("Bir kumaş parçasının eni 4 metre, boyu 6 metre.\n");
    printf("Bu kumaşın alanı kaç metrekaredir? ");
    if (scanf("%d", &answer) != 1) {
        printf("Geçersiz giriş. Kumaş toplanamadı.\n");
        return;
    }

    if (answer == 24) {
        printf("Doğru cevap! Bir kumaş topladın.\n");
        materials[2]++; // Kumaş sayısını artır
    } else {
        printf("Yanlış cevap! Kumaşı toplayamadın.\n");
    }
}

// Malzeme durumunu gösteren fonksiyon
void displayMaterials() {
    printf("\nMevcut malzemeler:\n");
    printf("Odun: %d\n", materials[0]);
    printf("İp: %d\n", materials[1]);
    printf("Kumaş: %d\n", materials[2]);
}

// Bot yapma fonksiyonu
void buildBoat() {
    if (materials[0] >= 3 && materials[1] >= 2 && materials[2] >= 1) {
        printf("\nTebrikler! Yeterli malzeme topladınız ve botu inşa ettiniz.\n");
        printf("Adadan başarıyla kaçtınız!\n");
    } else {
        printf("\nMalzemeler yeterli değil! Botu yapmak için şunlara ihtiyacın var:\n");
        if (materials[0] < 3) printf("- Daha fazla odun (%d eksik)\n", 3 - materials[0]);
        if (materials[1] < 2) printf("- Daha fazla ip (%d eksik)\n", 2 - materials[1]);
        if (materials[2] < 1) printf("- Daha fazla kumaş (%d eksik)\n", 1 - materials[2]);
    }
}
