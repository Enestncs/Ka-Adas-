#include <stdio.h>

int fibonacci() {
    int n = 0;

    printf("N değerini gir (N > 0): ");
    scanf("%d", &n);

    while (n < 0) {
        printf("pozitif bir tam sayı girin: ");
        scanf("%d", &n);
    }

    int fibonacci[n];
    fibonacci[0] = 1;
    if (n > 1) {
        fibonacci[1] = 1;
    }

    for (int counter = 2; counter < n; counter++) {
        fibonacci[counter] = fibonacci[counter - 1] + fibonacci[counter - 2];
    }

    printf("\nFibonacci Dizisi:\n");
    for (int counter = 0; counter < n; counter++) {
        printf("%d\n", fibonacci[counter]);
    }

    int toplam = 0;
    for (int counter = 0; counter < n; counter++) {
        toplam += fibonacci[counter];
    }

    printf("\nN'inci Fibonacci Sayısı: %d\n", fibonacci[n - 1]);
    printf("Fibonacci Dizisi Toplamı: %d\n", toplam);

    return 0;
}