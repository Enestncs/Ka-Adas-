#include <stdio.h>
#include <math.h>

int ucgen() {

  double a = 0, b = 0, c = 0;

  printf("1. kenarı giriniz:");
  scanf("%lf", &a);

  printf("2. kenarı giriniz:");
  scanf("%lf", &b);

  printf("3. kenarı giriniz:");
  scanf("%lf", &c);

  if ((a + b) > c && (a + c) > b && (b + c) > a){
    printf("\nBu Şekil Üçgen Eşitsizliğine Uymaktadır.");
  } 
  else{
    printf("\nBu Şekil Üçgen Eşitsizliğine Uymamaktadır.");
    goto bitir;
  }
  
  if (a == b && b == c) {
    printf("\n\nEşkenar Üçgen");
  }
  else if (a == b || a == c || b == c) {
    printf("\n\nİkizkenar Üçgen");
  } 
  else {
    printf("\n\nÇeşitkenar Üçgen");
  }

  double A = acos((b * b + c * c - a * a) / (2 * b * c)) * (180 / M_PI);
  double B = acos((a * a + c * c - b * b) / (2 * a * c)) * (180 / M_PI);
  double C = acos((a * a + b * b - c * c) / (2 * a * b)) * (180 / M_PI);
  
  if (A==90 || B==90 || C==90) {
    printf("\n\nBu bir dik üçgendir.\n");
  } else if (A < 90 && B < 90 && C < 90) {
    printf("Bu bir dar açılı üçgendir.\n");
  } else {
    printf("Bu bir geniş açılı üçgendir.\n");
  }

  printf("\nA açısı: %.2f derece\n", A);
  printf("B açısı: %.2f derece\n", B);
  printf("C açısı: %.2f derece\n", C);


  
  bitir:
  
  return 0;
}