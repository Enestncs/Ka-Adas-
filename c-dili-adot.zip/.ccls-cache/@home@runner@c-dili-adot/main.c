#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

// Envanter için struct tanımı
typedef struct {
    char name[20];
    int quantity;
} Item;

typedef struct {
    char name[20];         // Eşyanın adı
    char materials[3][20]; // Gerekli malzemeler
    int quantities[3];     // Gerekli malzeme miktarları
    int materialCount;     // Kaç farklı malzeme gerektiği
} Recipe;

typedef struct {
    char name[20];    // Yaratığın adı
    int health;       // Yaratığın sağlığı
    int attack;       // Yaratığın saldırı gücü
    int defense;      // Yaratığın savunma gücü
} Creature;

Item inventory[10]; // Maksimum 10 itemlik envanter
int itemCount = 0;  // Envanterdeki item sayısı

int energy = 10;    // Oyuncunun başlangıç enerjisi
int health = 5;     // Oyuncunun başlangıç canı

Recipe recipes[] = {
    {"Balta", {"Çubuk", "Taş", "Sarmaşık"}, {1, 1, 1}, 3},
    {"Bıçak", {"Kemik"}, {2}, 1},
    {"Tekne", {"Odun", "Sarmaşık", "Kumaş"}, {3, 2, 1}, 3},
    {"Kumaş", {"Sarmaşık"}, {3}, 1},
    {"Çubuk", {"Sarmaşık", "Kemik"}, {1, 1}, 2},
    {"Kamp Ateşi", {"Taş", "Odun"}, {3, 1}, 2},
    {"Pişmiş et", {"Kamp Ateşi", "Yaban Domuzu Eti"}, {1, 1}, 2}
};

// Yaratıklar
Creature boar = {"Yaban Domuzu", 5, 3, 1};


int recipeCount = sizeof(recipes) / sizeof(Recipe);

// Fonksiyon Prototipleri
void explore();
void randomEvent();
void addItem(char *name, int quantity);
void displayInventory();
void displayStats();
void craftItem();
void tryToEscape();
void consumeEnergy(int amount);
void attack(Creature *creature);
void defense(Creature *creature);
void specialAbility(Creature *creature);

// Terminal temizleme
void clearScreen() {
    #ifdef _WIN32
        system("cls"); // Windows
    #else
        system("clear"); // Linux/Mac
    #endif
}

// Durum özeti
void displayHeader() {
    printf("\n--------------------------\n");
    printf("Enerji: %d | Sağlık: %d\n", energy, health);
    printf("Envanter: ");
    for (int i = 0; i < itemCount; i++) {
        printf("%s(%d) ", inventory[i].name, inventory[i].quantity);
    }
    if (itemCount == 0) {
        printf("Boş");
    }
    printf("\n--------------------------\n");
}

// Ana Fonksiyon
int main() {
    int choice;
    srand(time(NULL)); // Rastgelelik için zaman tabanlı seed

    printf("Fırtına sonrası bir adada gözlerini açıyorsun.\n");
    printf("Adadan kaçmak için bir bot yapman gerekiyor!\n");

    while (1) {
        // Enerji ve sağlık kontrolü
        if (energy <= 0) {
            printf("\nEnerjin kalmadı! Dinlenmek zorundasın.\n");
            printf("Dinleniyorsun ve enerjin 2 puan arttı.\n");
            energy += 2;
        }

        if (health <= 0) {
            printf("\nCanın tükendi! Adada hayatta kalmayı başaramadın.\n");
            return 0;
        }
        
        displayHeader();

        // Ana menüyü göster
        printf("\nNe yapmak istiyorsun?\n");
        printf("1. Dolaş\n");
        printf("2. Kaçmayı dene\n");
        printf("3. Craft yap\n");
        printf("4. can ve enerji yenile\n");
        printf("5. Çıkış yap\n");
        printf("Seçimin: ");
        if (scanf("%d", &choice) != 1) {
            printf("Geçersiz giriş. Program sonlandırılıyor.\n");
            break;
        }

        // Kullanıcı seçimlerini işle
        switch (choice) {
            case 1:
                explore();
                break;
            case 2:
                tryToEscape();
                break;
            case 3:
                clearScreen();
                craftItem();
                break;
            case 4:
                clearScreen();
                printf("Canın ve enerjin yenileniyor...\n");
                addItem("Pişmiş et", -1);
                health = 5;
                energy = 10;
            case 5:
            clearScreen();
            printf("Oyundan çıktınız. Adada mahsur kaldınız.\n");
            default:
                printf("Geçersiz seçim. Lütfen tekrar deneyin.\n");
        }
    }
    return 0;
}

// Hamle seçenekleri
void playerAction(Creature *creature) {
    int action;
    printf("\nSavaşta ne yapmak istersin?\n");
    printf("1. Saldırı\n");
    printf("2. Savunma (Kalkan aç)\n");
    printf("3. Özel Yeteneği Kullan (Bıçağa ihtiyacın var)\n");
    printf("Seçiminizi yapın (1-3): ");
    scanf("%d", &action);
-
    switch (action) {
        case 1:
            attack(creature);
            break;
        case 2:
            defense(creature);
            break;
        case 3:
            specialAbility(creature);
            break;
        default:
            printf("Geçersiz seçim! Sadece 1-3 arası bir değer girin.\n");
            playerAction(creature);
            break;
    }
}

// Oyuncunun saldırısı
void attack(Creature *creature) {
    int damage = 3;  //saldırı gücü
    int damageToCreature = damage - creature->defense;
    if (damageToCreature < 0) damageToCreature = 0;  // Savunma çoksa zarar vermesin
    creature->health -= damageToCreature;
    printf("Sen %d hasar verdin! %s'nin sağlığı: %d\n", damageToCreature, creature->name, creature->health);
}

// Savunma
void defense(Creature *creature) {
    int defenseBonus = 2;  // Savunma bonusu
    printf("Savunma yaptın! Kalkanın %d hasar engelliyor.\n", defenseBonus);
    // Bu sırada yaratığın saldırısını daha düşük zararla alacak
    int damageToPlayer = creature->attack - defenseBonus;
    if (damageToPlayer < 0) damageToPlayer = 0;  // Savunma çoksa zarar vermesin
    health -= damageToPlayer;
    printf("%s sana %d hasar verdi! Senin sağlığın: %d\n", creature->name, damageToPlayer, health);
}

// Özel Yeteneği Kullanma
void specialAbility(Creature *creature) {
    // Bıçak kontrolü
    int hasKnife = 0;
    for (int i = 0; i < itemCount; i++) {
        if (strcmp(inventory[i].name, "Bıçak") == 0) {
            hasKnife = 1;
            break;
        }
    }

    if (!hasKnife) {
        printf("Özel yeteneğini kullanmak için bir bıçağa ihtiyacın var!\n");
        return;
    }

    // Bıçak varsa özel yeteneği kullan
    printf("Özel yeteneğini kullandın! Bıçakla %s'yi kesiyorsun...\n", creature->name);
    int specialDamage = 5;  // Özel yetenekten gelen hasar
    creature->health -= specialDamage;
    printf("%s'ye %d hasar verdin! %s'nin sağlığı: %d\n", creature->name, specialDamage, creature->name, creature->health);
}

//savaş fonksiyonu
void battle(Creature *creature) {
    int playerAttack = 3;  // Oyuncunun saldırı gücü
    int playerDefense = 1; // Oyuncunun savunma gücü
    int playerHealth = health;  // Oyuncunun mevcut sağlığı

    printf("\nBir %s ile karşılaştın! Savaş başlıyor...\n", creature->name);
    printf("%s'nin sağlığı: %d\n", creature->name, creature->health);
    printf("Senin sağlığın: %d\n", playerHealth);

    // Savaş devam ederken
    while (playerHealth > 0 && creature->health > 0) {
        printf("\n---- Yeni Tur ----\n");
        printf("Senin Sağlık: %d | %s Sağlık: %d\n", playerHealth, creature->name, creature->health);

        // Oyuncunun hamlesi
        playerAction(creature);

        // Eğer yaratığın sağlığı sıfıra düşmüşse, savaşı kazandığını bildir ve döngüden çık
        if (creature->health <= 0) {
            printf("\n%s'yi yendin!\n", creature->name);
            addItem("Yaban Domuzu Eti", 1);  // Yaratığı yendikten sonra ödül kazan
            creature->health = 5;
            return;
        }

        // Yaratığın saldırısı
        printf("\n%s saldırıya hazırlanıyor!\n", creature->name);
        int damageToPlayer = creature->attack - playerDefense;
        if (damageToPlayer < 0) damageToPlayer = 0;  // Savunma çoksa zarar vermesin
        playerHealth -= damageToPlayer;
        health = playerHealth; // Oyuncunun sağlığı güncelleniyor

        printf("%s sana %d hasar verdi! Senin sağlığın: %d\n", creature->name, damageToPlayer, playerHealth);

        // Eğer oyuncunun sağlığı sıfıra düşerse, oyunu kaybettiğini bildir ve döngüyü bitir
        if (playerHealth <= 0) {
            printf("\nCanın tükendi! Maalesef öldün.\n");
            return;
        }
    }
}


// İstatistikleri Gösterme
void displayStats() {
    printf("\nİstatistikler:\n");
    printf("Enerji: %d\n", energy);
    printf("Can: %d\n", health);
}

// Rastgele Dolaşma Fonksiyonu
void explore() {
    printf("\nEtrafta dolaşıyorsun...\n");
    randomEvent();
}

// Rastgele Olay Fonksiyonu
void randomEvent() {
    int event = rand() % 5; //5 farklı olay

    // Her malzeme için enerji maliyeti (farklı değerler atanacak)
    int energyCost = 0;
    switch (event) {
        case 0:  // Odun toplama
        clearScreen();
        {
            int hasAxe = 0;
            for (int i = 0; i < itemCount; i++) {
                if (strcmp(inventory[i].name, "Balta") == 0) {
                    hasAxe = 1;
                    break;
                }
            }
            if (hasAxe) {
                energyCost = 1;
                printf("Baltanızı kullanarak odun topladınız!\n");
                addItem("Odun", 1);
            } else {
                printf("Odun toplamak için bir baltaya ihtiyacınız var! Önce bir Balta yapmalısınız.\n");
            }
        }
        break;
        case 1:  // Sarmaşık toplama
            // Bıçak kontrolü
            clearScreen();
            {
                int hasKnife = 0;
                for (int i = 0; i < itemCount; i++) {
                    if (strcmp(inventory[i].name, "Bıçak") == 0) {
                        hasKnife = 1;
                        break;
                    }
                }
                if (!hasKnife) {
                    printf("Sarmaşık toplamak için bir bıçağa ihtiyacın var!\n");
                    return;
                }
                energyCost = 2;
                printf("Sarmaşık buldun!\n");
                addItem("Sarmaşık", 1);
            }
            break;
        case 2:  // Kemik toplama
            clearScreen();
            energyCost = 2;
            printf("Bir iskelet buldun ve kemik topladın!\n");
            addItem("Kemik", 1);
            break;
        case 3:  // Taş toplama
            clearScreen();
            energyCost = 1;
            printf("Yerde bir taş buldun!\n");
            addItem("Taş", 1);
            break;
        case 4:  // yaban domuzu ile karşılaştın
            clearScreen();
            battle(&boar);
            break;
        case 5:  // Hiçbir şey bulamadın
            clearScreen();
            printf("Hiçbir şey bulamadın. Şansını bir daha dene.\n");
            break;
            return;
    }
    consumeEnergy(energyCost);
}

// Enerji Tüketimi
void consumeEnergy(int amount) {
    if (energy < amount) {
        printf("Yeterli enerjin yok! Bu eylemi gerçekleştiremiyorsun.\n");
    } else {
        energy -= amount;
    }
}

// Yeni Item Ekleme veya Güncelleme Fonksiyonu
void addItem(char *name, int quantity) {
    for (int i = 0; i < itemCount; i++) {
        if (strcmp(inventory[i].name, name) == 0) {
            inventory[i].quantity += quantity;
            printf("%s miktarı güncellendi: %d\n", name, inventory[i].quantity);
            return;
        }
    }
    if (itemCount < 10) {
        strcpy(inventory[itemCount].name, name);
        inventory[itemCount].quantity = quantity;
        itemCount++;
        printf("%s envantere eklendi: %d\n", name, quantity);
    } else {
        printf("Envanter dolu! Yeni item eklenemiyor.\n");
    }
}

// Envanteri Gösterme Fonksiyonu
void displayInventory() {
    printf("\nMevcut Envanter:\n");
    for (int i = 0; i < itemCount; i++) {
        printf("%s: %d\n", inventory[i].name, inventory[i].quantity);
    }
}

// Craft Yapma Fonksiyonu
void craftItem() {
    printf("\nCraft edilebilecek eşyalar:\n");
    for (int i = 0; i < recipeCount; i++) {
        printf("%d. %s (", i + 1, recipes[i].name);
        for (int j = 0; j < recipes[i].materialCount; j++) {
            printf("%s: %d", recipes[i].materials[j], recipes[i].quantities[j]);
            if (j < recipes[i].materialCount - 1) printf(", ");
        }
        printf(")\n");
    }
    printf("Craft etmek istediğiniz eşyanın numarasını girin: ");
    int choice;
    if (scanf("%d", &choice) != 1 || choice < 1 || choice > recipeCount) {
        printf("Geçersiz seçim.\n");
        return;
    }

    Recipe selectedRecipe = recipes[choice - 1];

    for (int i = 0; i < selectedRecipe.materialCount; i++) {
        int found = 0;
        for (int j = 0; j < itemCount; j++) {
            if (strcmp(inventory[j].name, selectedRecipe.materials[i]) == 0 &&
                inventory[j].quantity >= selectedRecipe.quantities[i]) {
                found = 1;
                break;
            }
        }
        if (!found) {
            printf("Yeterli %s yok. Craft işlemi başarısız.\n", selectedRecipe.materials[i]);
            return;
        }
    }

    for (int i = 0; i < selectedRecipe.materialCount; i++) {
        for (int j = 0; j < itemCount; j++) {
            if (strcmp(inventory[j].name, selectedRecipe.materials[i]) == 0) {
                inventory[j].quantity -= selectedRecipe.quantities[i];
            }
        }
    }
    printf("%s craft edildi!\n", selectedRecipe.name);
    addItem(selectedRecipe.name, 1);
}


// Kaçma Fonksiyonu
void tryToEscape() {
    int hasBoat = 0;
    for (int i = 0; i < itemCount; i++) {
        if (strcmp(inventory[i].name, "Tekne") == 0) {
            hasBoat = 1;
            break;
        }
    }

    if (hasBoat) {
        printf("Tebrikler! Botu yapmayı başardınız ve adadan başarıyla kaçtınız.\n");
        exit(0);
    } else {
        printf("\nHenüz bir bot yapmadınız! Kaçmak için bir bot yapmanız gerekiyor.\n");
    }
}