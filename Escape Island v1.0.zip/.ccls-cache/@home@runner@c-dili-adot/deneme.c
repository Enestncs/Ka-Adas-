#include <stdio.h>

int main2(){

int not = 0;

  printf("notunuz kaç");
  scanf("%d", &not);

  if (not < 0 || not > 100){
    printf("geçersiz not girdiniz");
      goto bitir;
  }

  else if (not < 50){
    printf("kaldınız\n");
  }
  else {
  printf("geçtiniz\n");
  }

switch (not/10){
  case 10:
  case 9:
      printf("Harf notu: A\n");
      break;
  case 8:
      printf("Harf notu: B\n");
      break;
  case 7:
      printf("Harf notu: C\n");
      break;
  case 6:
      printf("Harf notu: D\n");
      break;
  default:
      printf("Harf notu: F\n");    
      break;
}

bitir:

  return 0;
}