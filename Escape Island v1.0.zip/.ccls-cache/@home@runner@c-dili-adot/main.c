#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

// Struct definition for inventory
typedef struct {
  char name[20];
  int quantity;
} Item;

typedef struct {
  char name[20];         // item name
  char materials[3][20]; // Required materials
  int quantities[3];     // Required material quantities
  int materialCount;     // How many different materials are required
} Recipe;

typedef struct {
  char name[20]; // creature name
  int health;    // creature's health
  int attack;    // Attack power of the creature
  int defense;   // Creature's defensive power
} Creature;

Item inventory[10]; // Maximum inventory
int itemCount = 0;  // Number of items in inventory

int energy = 10;    // starting energy
int health = 5;     // starting health
int maxHealth = 5;  // maximum health
int maxEnergy = 10; // maximum energy

// recipes
Recipe recipes[] = {{"Axe", {"stick", "Rock", "Ivy"}, {1, 1, 1}, 3},
                    {"Knife", {"Bone"}, {2}, 1},
                    {"Boat", {"Wood", "Ivy", "fabric"}, {3, 2, 1}, 3},
                    {"fabric", {"Ivy"}, {3}, 1},
                    {"stick", {"Ivy", "Bone"}, {1, 1}, 2}};

// Creatures
Creature boar = {"Wild Boar", 5, 3, 1};

int recipeCount = sizeof(recipes) / sizeof(Recipe);

// Functions
void explore();
void randomEvent();
void addItem(char *name, int quantity);
void displayInventory();
void displayStats();
void craftItem();
void tryToEscape();
void consumeEnergy(int amount);
void attack(Creature *creature);
void specialAbility(Creature *creature);

// terminal clearing
void clearScreen() {
#ifdef _WIN32
  system("cls");
#else
  system("clear");
#endif
}

// status bar
void displayBar(int current, int max, char *label) {
  int barWidth = 20;
  int filledLength = (current * barWidth) / max;

  printf("%s: [", label);
  for (int i = 0; i < barWidth; i++) {
    if (i < filledLength)
      printf("█");
    else
      printf(" ");
  }
  printf("] %d/%d\n", current, max);
}

// Status
void displayHeader() {
  printf("\n====================================\n");
  displayBar(health, maxHealth, "health");
  displayBar(energy, maxEnergy, "energy");
  printf("Inventory: ");
  for (int i = 0; i < itemCount; i++) {
    printf("%s(%d) ", inventory[i].name, inventory[i].quantity);
  }
  if (itemCount == 0) {
    printf("Empty");
  }
  printf("\n====================================\n");
}

// main function
int main() {
  int choice;
  srand(time(NULL));

  printf("You wake up on an island after a storm.\n");
  printf("To escape the island you need to build a boat!\n");

  while (1) {
    if (energy <= 0) {
      printf("\nYou have no energy left! You have to rest.\n");
      printf("You rest and your energy increases by 2 points.\n");
      energy += 2;
    }

    if (health <= 0) {
      printf("\nYou're out of health! You couldn't survive on the island.\n");
      return 0;
    }

    displayHeader();

    // main menu
    printf("\nWhat would you like to do?\n");
    printf("1. explore\n");
    printf("2. Try to escape\n");
    printf("3. Craft\n");
    printf("4. Log Out\n");
    printf("Your choice: ");
    if (scanf("%d", &choice) != 1) {
      printf("Invalid input. Program terminating.\n");
      break;
    }

    // Process user selections
    switch (choice) {
    case 1:
      explore();
      break;
    case 2:
      tryToEscape();
      break;
    case 3:
      clearScreen();
      craftItem();
      break;
    case 4:
      clearScreen();
      printf("You are out of the game. You are stranded on the island.\n");
      return 0;
    default:
      printf("Invalid selection. Please try again.\n");
    }
  }
  return 0;
}

// Move options
void playerAction(Creature *creature) {
  int action;
  printf("\nWhat do you want to do in war?\n");
  printf("1. Attack\n");
  printf("2. Special Ability (You need a knife)\n");
  printf("Make your choice (1-2): ");
  scanf("%d", &action);

  switch (action) {
  case 1:
    attack(creature);
    break;
  case 2:
    specialAbility(creature);
    break;
  default:
    printf("Invalid selection! Only enter a value between 1-2.\n");
    playerAction(creature);
    break;
  }
}

// Player's attack
void attack(Creature *creature) {
  int damage = 3;
  int damageToCreature = damage - creature->defense;
  if (damageToCreature < 0)
    damageToCreature = 0;
  creature->health -= damageToCreature;
  printf("You dealt %d damage! %s's health is %d\n", damageToCreature,
         creature->name, creature->health);
}

// Player's Special Ability
void specialAbility(Creature *creature) {
  int hasKnife = 0;
  for (int i = 0; i < itemCount; i++) {
    if (strcmp(inventory[i].name, "Knife") == 0) {
      hasKnife = 1;
      break;
    }
  }

  if (!hasKnife) {
    printf("You need a knife to use your special ability!\n");
    return;
  }

  printf("You used your special ability! You cut %s with the knife...\n",
         creature->name);
  int specialDamage = 5;
  creature->health -= specialDamage;
  printf("You dealt %d damage to %s! %s's health: %d\n", creature->name,
         specialDamage, creature->name, creature->health);
}

// combat function
void battle(Creature *creature) {
  int playerAttack = 3;      // Player's attack power
  int playerDefense = 1;     // Player's defensive strength
  int playerHealth = health; // Player's current health

  while (playerHealth > 0 && creature->health > 0) {
    printf("\n---- New Round ----\n");
    printf("Your Health: %d | %s Health: %d\n", playerHealth, creature->name,
           creature->health);

    playerAction(creature);

    if (creature->health <= 0) {
      printf("\nYou defeated %s!\n", creature->name);
      addItem("Wild Boar Meat", 1);
      creature->health = 5;
      return;
    }

    // creature attack
    printf("\n%s is preparing to attack!\n", creature->name);
    int damageToPlayer = creature->attack - playerDefense;
    if (damageToPlayer < 0)
      damageToPlayer = 0;
    playerHealth -= damageToPlayer;
    health = playerHealth; // Player's health is updated

    printf("%s dealt %d damage to you! Your health: %d\n", creature->name,
           damageToPlayer, playerHealth);

    if (playerHealth <= 0) {
      printf("\nYou're out of health! Unfortunately, you're dead.\n");
      return;
    }
  }
}

// Statistics
void displayStats() {
  printf("\nStatistics:\n");
  printf("Energy: %d\n", energy);
  printf("Health: %d\n", health);
}

// Random Explore Function
void explore() {
  printf("\nYou're wandering around...\n");
  randomEvent();
}

// Random Event Function
void randomEvent() {
  int event = rand() % 7;
  int energyCost = 0;
  switch (event) {
  case 0: // collecting wood
    clearScreen();
    {
      int hasAxe = 0;
      for (int i = 0; i < itemCount; i++) {
        if (strcmp(inventory[i].name, "Axe") == 0) {
          hasAxe = 1;
          break;
        }
      }
      if (hasAxe) {
        energyCost = 1;
        printf("You collected wood using your axe!\n");
        addItem("Wood", 1);
      } else {
        printf(
            "To gather wood you need an axe! First you must craft an axe.\n");
      }
    }
    break;
  case 1: // ivy picking
    clearScreen();
    {
      int hasKnife = 0;
      for (int i = 0; i < itemCount; i++) {
        if (strcmp(inventory[i].name, "Knife") == 0) {
          hasKnife = 1;
          break;
        }
      }
      if (!hasKnife) {
        printf("You need a knife to collect vines!\n");
        return;
      }
      energyCost = 2;
      printf("You found ivy!\n");
      addItem("Ivy", 1);
    }
    break;
  case 2: // Collecting bones
    clearScreen();
    energyCost = 2;
    printf("You found a skeleton and collected bones!\n");
    addItem("Bone", 1);
    break;
  case 3: // Collecting stones
    clearScreen();
    energyCost = 1;
    printf("You found a stone on the ground!\n");
    addItem("Stone", 1);
    break;
  case 4: // Encounter with a wild boar
    clearScreen();
    printf("\nYou've encountered a wild boar! The battle begins...\n");
    battle(&boar);
    break;
  case 5: // life renewal
    clearScreen();
    printf("While wandering, you came across a fruit tree and ate,\nYour life "
           "was renewed.\n");
    health = 5;
    break;
  case 6: // energy renewal
    clearScreen();
    printf("While you were walking, you came across a bush and you lay down "
           "and rested, your energy was renewed.\n");
    energy = 10;
    break;
    return;
  }
  consumeEnergy(energyCost);
}

// consuming Energy
void consumeEnergy(int amount) {
  if (amount > 0) {
    energy -= amount;
    if (energy < 0) {
      energy = 0;
    }
    printf("Energy spent. Remaining energy: %d\n", energy);
  }
}

// New Item Adding or Update Function
void addItem(char *name, int quantity) {
  for (int i = 0; i < itemCount; i++) {
    if (strcmp(inventory[i].name, name) == 0) {
      inventory[i].quantity += quantity;
      if (inventory[i].quantity <= 0) {
        for (int j = i; j < itemCount - 1; j++) {
          inventory[j] = inventory[j + 1];
        }
        itemCount--;
      }
      return;
    }
  }
  if (quantity > 0 && itemCount < 10) {
    strcpy(inventory[itemCount].name, name);
    inventory[itemCount].quantity = quantity;
    itemCount++;
  }
}

// Inventory Display Function
void displayInventory() {
  printf("\nCurrent Inventory:\n");
  for (int i = 0; i < itemCount; i++) {
    printf("%s: %d\n", inventory[i].name, inventory[i].quantity);
  }
}

// Crafting Function
void craftItem() {
  printf("\nItems that can be crafted:\n");
  for (int i = 0; i < recipeCount; i++) {
    printf("%d. %s (", i + 1, recipes[i].name);
    for (int j = 0; j < recipes[i].materialCount; j++) {
      printf("%s: %d", recipes[i].materials[j], recipes[i].quantities[j]);
      if (j < recipes[i].materialCount - 1)
        printf(", ");
    }
    printf(")\n");
  }
  printf("Enter the number of the item you want to craft: ");
  int choice;
  if (scanf("%d", &choice) != 1 || choice < 1 || choice > recipeCount) {
    printf("Invalid selection.\n");
    return;
  }

  Recipe selectedRecipe = recipes[choice - 1];

  for (int i = 0; i < selectedRecipe.materialCount; i++) {
    int found = 0;
    for (int j = 0; j < itemCount; j++) {
      if (strcmp(inventory[j].name, selectedRecipe.materials[i]) == 0 &&
          inventory[j].quantity >= selectedRecipe.quantities[i]) {
        found = 1;
        break;
      }
    }
    if (!found) {
      printf("Not enough %s. Crafting failed.\n", selectedRecipe.materials[i]);
      return;
    }
  }

  for (int i = 0; i < selectedRecipe.materialCount; i++) {
    for (int j = 0; j < itemCount; j++) {
      if (strcmp(inventory[j].name, selectedRecipe.materials[i]) == 0) {
        inventory[j].quantity -= selectedRecipe.quantities[i];
      }
    }
  }
  printf("%s crafted!\n", selectedRecipe.name);
  addItem(selectedRecipe.name, 1);
}

// Escape Function
void tryToEscape() {
  int hasBoat = 0;
  for (int i = 0; i < itemCount; i++) {
    if (strcmp(inventory[i].name, "Boat") == 0) {
      hasBoat = 1;
      break;
    }
  }

  if (hasBoat) {
    printf("Congratulations! You managed to build the boat and successfully "
           "escaped from the island.\n");
    exit(0);
  } else {
    printf("\nYou haven't built a Boat yet! You need to build a boat to "
           "escape.\n");
  }
}